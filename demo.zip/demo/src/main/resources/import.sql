INSERT INTO statut (denomination) VALUES ('Occupé'), ('En ligne');

INSERT INTO utilisateur (nom, prenom, statut_id) VALUES ('John', 'DOE', 1), ('Fly', 'Jason', 2);