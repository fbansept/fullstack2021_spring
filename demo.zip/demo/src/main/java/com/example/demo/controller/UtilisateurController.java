package com.example.demo.controller;

import com.example.demo.dao.UtilisateurDao;
import com.example.demo.model.Utilisateur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UtilisateurController {

    private UtilisateurDao utilisateurDao;

    @Autowired
    UtilisateurController(UtilisateurDao utilisateurDao){
        this.utilisateurDao = utilisateurDao;
    }

    @GetMapping("/liste-utilisateur")
    public List<Utilisateur> afficheListeUtilisateur () {
        return utilisateurDao.findAll();
    }

    @GetMapping("/utilisateur/{id}")
    public Utilisateur afficheUtilisateur(@PathVariable Integer id) {

        return utilisateurDao.findById(id).orElse(null);
    }

    @GetMapping("/utilisateur-nom/{nom}")
    public Utilisateur afficheUtilisateurParNom(@PathVariable String nom) {

        return utilisateurDao.findByNom(nom);
    }


}
